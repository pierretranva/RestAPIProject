# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['greenapple']

package_data = \
{'': ['*']}

install_requires = \
['asyncio>=3.4.3,<4.0.0',
 'fastapi[all]>=0.78.0,<0.79.0',
 'loguru>=0.5.3,<0.6.0',
 'pydantic-jsonapi>=0.11.0,<0.12.0',
 'pydantic[dotenv]>=1.8.2,<2.0.0',
 'python-dotenv>=0.15.0,<0.16.0',
 'typer[all]>=0.4.1,<0.5.0',
 'types-requests>=2.27.13,<3.0.0']

entry_points = \
{'console_scripts': ['greenapple = greenapple.main:cli_app']}

setup_kwargs = {
    'name': 'greenapple',
    'version': '0.0.1',
    'description': 'Project greenapple - Web API service',
    'long_description': None,
    'author': 'Obscurity Labs',
    'author_email': None,
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
